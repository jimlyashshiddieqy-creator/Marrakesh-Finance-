import {financeUI, submitFinance} from './finance-ui.js';
import {validateFinance, init as initFinance, record as recordFinance} from './finance.js';
import {MAX, uid, money, shares, evaluate, fresh, paid, due, addPayment, confirmPayment, finishPool, validate, validDate} from './core.js';

const $ = s => document.querySelector(s);
const key = 'marrakesh-finance-v2';
let db = fresh(), storageBlocked = false, readOnly = false;

try {
  const raw = localStorage.getItem(key);
  if (raw) {
    db = validate(JSON.parse(raw));
    validateFinance(db);
  }
} catch {
  storageBlocked = true;
}

let financeMonth = '';
let financeFilter = 'all';
let active = db.members[0].id;
let tab = 'kas';
let path = 'tal';
let selected = {tal: null, pool: null, lt: null};
let expr = '0';
let people = 6;
let calcLabel = '';
let just = false;
let cash = '';
let lastSaved = null;
let pendingImportData = null;
let fxEnabled = true;
let fxRaf = null;

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const fmt = c => (c / 100).toLocaleString('id-ID', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + ' MAD';
const num = n => n.toLocaleString('id-ID', {maximumFractionDigits: 8});
const name = id => db.members.find(m => m.id === id)?.name ?? 'Anggota';
const initials = str => String(str || '').split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase();
const today = () => new Intl.DateTimeFormat('en-CA', {timeZone: 'Africa/Casablanca', year: 'numeric', month: '2-digit', day: '2-digit'}).format(new Date());
const collection = k => k === 'tal' ? db.tal : k === 'pool' ? db.pools : db.programs;
const current = k => collection(k).find(x => x.id === selected[k]) ?? collection(k)[0];
const btn = (text, action, cls = '', attrs = '') => `<button type="button" data-action="${action}" class="${cls}" ${attrs}>${text}</button>`;
const options = (val, filter = () => true) => db.members.filter(filter).map(m => `<option value="${esc(m.id)}" ${m.id === val ? 'selected' : ''}>${esc(m.name)}</option>`).join('');
const field = (label, id, type = 'text', value = '', extra = '') => `<label class="field">${label}<input name="${id}" id="${id}" type="${type}" value="${esc(value)}" ${extra}></label>`;
const select = (label, id, html) => `<label class="field">${label}<select name="${id}" id="${id}">${html}</select></label>`;

// Jika penyimpanan masih kosong saat pertama kali dibuka, isi contoh data Kas supaya grafik donat & batang langsung terlihat jelas
try {
  const f = initFinance(db);
  if (!localStorage.getItem(key) && !f.entries.length && !f.items.length) {
    const d = today();
    recordFinance(db, {member: 'm1', date: d, deadline: '', category: 'Umum', ref: '', type: 'deposit', account: 'cash', amount: 120000, note: 'Iuran Kas Bulanan (6 Anggota × 200 MAD)'}, active);
    recordFinance(db, {member: 'm2', date: d, deadline: '', category: 'Umum', ref: '', type: 'deposit', account: 'bank', amount: 60000, note: 'Saldo Cadangan Kas Digital CIH'}, active);
    recordFinance(db, {member: 'm1', date: d, deadline: '', category: 'Umum', ref: '', type: 'expense', account: 'bank', amount: 24900, note: 'Tagihan WiFi Maroc Telecom'}, active);
    recordFinance(db, {member: 'm3', date: d, deadline: '', category: 'Umum', ref: '', type: 'expense', account: 'cash', amount: 18500, note: 'Isi Ulang Tabung Gas & Sabun Cuci Piring'}, active);
    recordFinance(db, {member: 'm5', date: d, deadline: '', category: 'Umum', ref: '', type: 'loan', account: 'cash', amount: 15000, note: 'Pinjam tunai bayar kurir paket'}, active);
    f.items.push(
      {id: uid(), name: 'Setrika Uap Philips', condition: 'Dicatat', borrower: 'm4', deadline: d, history: [{at: new Date().toISOString(), action: 'Dipinjam', member: 'm4', condition: 'Dicatat', actor: active}]},
      {id: uid(), name: 'Kabel Roll Panjang 10m', condition: 'Dicatat', borrower: null, deadline: null, history: [{at: new Date().toISOString(), action: 'Dikembalikan', member: 'm1', condition: 'Dicatat', actor: active}]}
    );
  }
} catch {}

let toastTimer;
function toast(msg) {
  $('#toast').textContent = msg;
  $('#toast').style.display = 'block';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $('#toast').style.display = 'none', 4500);
}

function modal(html) {
  $('#modalContent').innerHTML = html;
  $('#modal').showModal();
}

function close() {
  $('#modal').close();
}

function transact(fn) {
  if (storageBlocked || readOnly) throw Error('Pencatatan diblokir. Muat ulang halaman atau ekspor data terlebih dahulu.');
  const before = structuredClone(db);
  try {
    const stored = localStorage.getItem(key);
    if (stored && JSON.parse(stored).revision !== db.revision) throw Error('Data berubah di tab lain. Muat ulang halaman sebelum melanjutkan.');
    fn();
    db.audit ??= [];
    const changes = {};
    for (const k of ['tal', 'pools', 'programs', 'finance']) {
      if (JSON.stringify(before[k]) !== JSON.stringify(db[k])) {
        changes[k] = {before: before[k] ?? null, after: structuredClone(db[k] ?? null)};
      }
    }
    if (Object.keys(changes).length) {
      db.audit.push({id: uid(), actor: active, at: new Date().toISOString(), changes});
    }
    db.revision++;
    validate(db);
    validateFinance(db);
    localStorage.setItem(key, JSON.stringify(db));
    $('#saveStatus').textContent = 'Tersimpan di browser ini';
  } catch (e) {
    db = before;
    throw e;
  }
}

function heading(kicker, title, action = '') {
  return `<div class="heading"><div><div class="eyebrow">${kicker}</div><h2>${title}</h2></div>${action}</div>`;
}

function empty(symbol, title, text, action = '') {
  return `<div class="empty"><div class="symbol">${symbol}</div><h3>${title}</h3><p>${text}</p>${action}</div>`;
}

function renderProfile() {
  const logo = $('#profileLogo');
  logo.replaceChildren();
  if (typeof db.profilePhoto === 'string' && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(db.profilePhoto)) {
    const img = document.createElement('img');
    img.src = db.profilePhoto;
    img.alt = 'Profil Brankas Marrakesh Boy';
    logo.append(img);
  } else logo.textContent = '❄️';
}

function render() {
  renderProfile();
  $('#activeUser').innerHTML = options(active);
  document.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  $('#badge').textContent = String(pending().length);
  $('#workspace').innerHTML =
    tab === 'kas' ? financeUI({db, active, esc, fmt, name, field, select, options, btn, today, month: financeMonth, filter: financeFilter}) :
    tab === 'kalkulator' ? renderCalc() :
    tab === 'belanja' ? renderShopping() :
    tab === 'jangka' ? renderLt() :
    tab === 'lainnya' ? renderOther() :
    renderConfirm();
  if (tab === 'kalkulator') updateCalc();
}

function renderCalc() {
  return `<div class="columns"><section class="glass panel">${heading('HITUNG DULU, BAGI DENGAN PAS', 'Kalkulator Hitung', btn('Contoh →', 'example', 'muted-button'))}<div class="screen"><input id="calcLabel" maxlength="120" aria-label="Nama hitungan" placeholder="Nama hitungan, misal: Masak Telur Baladi" value="${esc(calcLabel)}"><div class="expression" id="expression"></div><div class="result"><strong id="result">0</strong><small>MAD</small></div><div class="splitbar"><span>Dibagi patungan</span><div>${btn('−', 'less', '', 'aria-label="Kurangi jumlah orang"')} <b id="people">${people} orang</b> ${btn('+', 'more', '', 'aria-label="Tambah jumlah orang"')}</div><span class="amount" id="perPerson"></span></div></div><div class="quickkeys">${btn('(', 'key', '', 'data-value="("')}${btn(')', 'key', '', 'data-value=")"')}${btn('÷ ' + people + ' org', 'divide')}${btn('↑ Simpan', 'saveTape')}</div><div class="keys">${[['AC', 'clear', 'fn danger'], ['⌫', 'back', 'fn'], ['%', 'key', 'fn'], ['÷', 'key', 'op'], ['7', 'key', ''], ['8', 'key', ''], ['9', 'key', ''], ['×', 'key', 'op'], ['4', 'key', ''], ['5', 'key', ''], ['6', 'key', ''], ['−', 'key', 'op'], ['1', 'key', ''], ['2', 'key', ''], ['3', 'key', ''], ['+', 'key', 'op'], ['00', 'key', ''], ['0', 'key', ''], ['.', 'key', ''], ['=', 'equals', 'eq']].map(([v, a, c]) => btn(v, a, c, `data-value="${v}" aria-label="${v === '⌫' ? 'Hapus satu karakter' : v}"`)).join('')}</div><p class="hint">Keyboard: angka, + − × ÷, %, kurung, Enter dan Backspace.<br>Persen berarti ÷ 100. Contoh: 200 × 10% = 20.</p></section><div class="stack"><section class="glass panel">${heading('INTEGRASI CEPAT', 'Dari hitungan ke catatan')}<div class="well"><div class="row"><small>Total hitungan</small><strong class="mono" id="sideTotal"></strong></div><div class="line"></div><div class="row"><small>Bagian per orang</small><b class="amount" id="sideShare"></b></div><p class="tally" id="splitNote"></p></div><div class="card" style="margin-top:16px"><label class="label" for="cash">Uang dibayar / terkumpul (opsional)</label><input id="cash" class="wide mono" type="number" min="0" step="0.01" placeholder="Contoh: 180" value="${esc(cash)}"><p id="change" class="tally"></p></div><div class="buttons" style="margin-top:18px">${btn('→ Talangi Dulu', 'toTal', 'primary')}${btn('→ Kumpul Dana', 'toPool', 'purplebtn')}</div><p class="hint">Catatan belanja menggunakan 6 anggota. Jumlah pembagi kalkulator bebas diubah.</p></section><section class="glass panel">${heading('PITA KALKULATOR', 'Riwayat Hitungan', btn('Bersihkan', 'clearTape', 'muted-button'))}<div class="tape">${db.tape.length ? db.tape.map(t => `<div class="tapeline">${btn(`<strong>${esc(t.label)}</strong><small class="mono">${esc(t.expr)} = ${num(t.result)}</small><small>${t.people} pembagi · Klik untuk memuat</small>`, 'loadTape', '', `data-id="${esc(t.id)}"`)}${btn('×', 'deleteTape', '', `data-id="${esc(t.id)}" aria-label="Hapus riwayat"`)}</div>`).join('') : empty('≋', 'Pita masih kosong', 'Hitungan yang lu simpan akan muncul di sini.')}</div><div class="line"></div><div class="row"><small>Total akumulasi</small><strong class="amount">${num(db.tape.reduce((s, t) => s + t.result, 0))} MAD</strong></div>${btn('Muat total ke layar', 'sumTape', 'wide', db.tape.length ? '' : 'disabled')}</section></div></div>`;
}

function calcValue() { return evaluate(expr); }
function calcCents() { const v = calcValue(); return money((Math.round((v + Number.EPSILON) * 100) / 100).toFixed(2)); }
function distribution(c, n) { const s = shares(c, n), hi = s[0], lo = s.at(-1); return hi === lo ? `${n} orang × ${fmt(hi)} = ${fmt(c)}` : `${s.filter(x => x === hi).length} orang × ${fmt(hi)}; ${s.filter(x => x === lo).length} orang × ${fmt(lo)}`; }

function updateCalc() {
  if (!$('#expression')) return;
  $('#expression').textContent = expr.replaceAll('*', ' × ').replaceAll('/', ' ÷ ');
  let v;
  try {
    v = calcValue();
  } catch (e) {
    $('#result').textContent = '…';
    $('#sideTotal').textContent = 'Belum valid';
    $('#sideShare').textContent = '—';
    $('#perPerson').textContent = '—';
    $('#splitNote').textContent = e.message;
    $('#change').textContent = 'Selesaikan hitungan terlebih dahulu.';
    return;
  }
  $('#result').textContent = num(v);
  $('#sideTotal').textContent = fmt(Math.round(v * 100));
  if (v < 0) {
    $('#perPerson').textContent = '—';
    $('#sideShare').textContent = '—';
    $('#splitNote').textContent = 'Hasil negatif tidak bisa digunakan sebagai tagihan.';
  } else {
    const c = Math.round(v * 100), s = shares(c, people), range = s[0] === s.at(-1) ? fmt(s[0]) : `${fmt(s.at(-1))} – ${fmt(s[0])}`;
    $('#perPerson').textContent = range;
    $('#sideShare').textContent = range;
    $('#splitNote').textContent = distribution(c, people);
  }
  if (cash === '') $('#change').textContent = 'Masukkan uang dibayar untuk menghitung kembalian.';
  else {
    const c = Number(cash);
    if (!Number.isFinite(c) || c < 0 || c > 1e9) {
      $('#change').textContent = 'Nominal uang tidak valid.';
      return;
    }
    const diff = Math.round(c * 100) - Math.round(v * 100);
    $('#change').textContent = (diff >= 0 ? 'Sisa / kembalian: ' : 'Kurang bayar: ') + fmt(Math.abs(diff));
  }
}

function input(v) {
  v = v.replace('×', '*').replace('÷', '/').replace('−', '-');
  if (expr.length > 290) throw Error('Hitungan terlalu panjang.');
  if (just) {
    if (/[0-9.(]/.test(v[0])) expr = '';
    else expr = String(calcValue());
    just = false;
  }
  if (expr === '0' && /^\d/.test(v)) expr = '';
  expr += v;
  updateCalc();
}

function saveTape() {
  const v = calcValue(), signature = JSON.stringify([expr, calcLabel, people]);
  if (lastSaved === signature) {
    toast('Hitungan ini sudah disimpan.');
    return;
  }
  transact(() => db.tape.unshift({id: uid(), label: calcLabel.trim() || 'Hitungan Kalkulator', expr, result: v, people}));
  lastSaved = signature;
  render();
  toast('Hitungan tersimpan.');
}

function renderShopping() {
  return `<section class="glass panel sectiontop">${heading('PATUNGAN BELANJA', 'Mau belanja? Pilih jalurnya.', btn('▦ Kalkulator', 'openCalc'))}<div class="tabs"><button type="button" data-action="pathTal" class="${path === 'tal' ? 'selected' : ''}"><strong>♧ Talangi Dulu</strong><small>Satu orang bayar toko. Anggota lainnya mengganti bagian masing-masing.</small></button><button type="button" data-action="pathPool" class="${path === 'pool' ? 'selected' : ''}"><strong>♧ Kumpulkan Dulu</strong><small>Setor ke pengelola, catat belanja, lalu tentukan sisa uangnya.</small></button></div></section>${path === 'tal' ? renderTal() : renderPool()}`;
}

function selector(kind) {
  return collection(kind).map(x => {
    const total = kind === 'tal' ? x.total : x.payments.filter(p => p.status === 'SETTLED').reduce((a, p) => a + p.amount, 0);
    return btn(`<div class="row"><strong>${esc(x.title)}</strong><b class="amount">${fmt(total)}</b></div><small>${kind === 'tal' ? 'Ditalangi' : 'Pengelola'}: ${esc(name(x.owner))}${kind === 'pool' && x.closed ? ' · Ditutup' : ''}</small>`, 'select', 'selector ' + (current(kind)?.id === x.id ? 'selected' : ''), `data-kind="${kind}" data-id="${esc(x.id)}"`);
  }).join('');
}

function paymentForm(kind, x) {
  const eligible = db.members.filter(m => (active === x.owner || active === m.id) && (kind === 'lt' || due(db, x, kind, m.id) - paid(x, m.id) - paid(x, m.id, 'PENDING') > 0));
  if (!eligible.length) return `<p class="note">Tidak ada tagihan yang bisa dicatat oleh anggota aktif ini.</p>`;
  return `<form id="paymentForm" data-kind="${kind}" data-id="${esc(x.id)}" class="well formgrid">${select('Dibayar oleh', 'payMember', eligible.map(m => `<option value="${esc(m.id)}">${esc(m.name)}</option>`).join(''))}${field('Nominal (MAD)', 'payAmount', 'number', kind === 'lt' ? '' : ((due(db, x, kind, eligible[0].id) - paid(x, eligible[0].id) - paid(x, eligible[0].id, 'PENDING')) / 100).toFixed(2), 'required min="0.01" max="1000000000" step="0.01"')}${field('Tanggal pembayaran', 'payDate', 'date', today(), 'required')}${field('Metode / catatan bukti', 'payMethod', 'text', '', 'required maxlength="200" placeholder="Transfer CIH / tunai"')}<p class="hint full">${active === x.owner ? 'Penerima mencatat langsung sebagai uang yang sudah diterima.' : 'Pembayaran akan menunggu konfirmasi penerima.'}</p><button class="primary full" type="submit">+ Catat Pembayaran</button></form>`;
}

function membersList(kind, x) {
  return db.members.map(m => {
    const total = due(db, x, kind, m.id), settled = paid(x, m.id), pendingAmount = paid(x, m.id, 'PENDING'), remaining = Math.max(0, total - settled), status = remaining === 0 ? 'LUNAS' : settled ? 'SEBAGIAN' : 'BELUM BAYAR';
    return `<div class="paymentrow"><div class="row"><b>${esc(m.name)} ${m.id === x.owner ? '· Penerima' : ''}</b><span class="status ${remaining === 0 ? 'ok' : ''}">${status}</span></div><small>Terima ${fmt(settled)} / ${fmt(total)} · Sisa ${fmt(remaining)}</small>${pendingAmount ? `<small style="color:var(--amber)">Menunggu konfirmasi: ${fmt(pendingAmount)}</small>` : ''}</div>`;
  }).join('');
}

function history(kind, x) {
  return `<details class="settled-drawer"><summary>Riwayat pembayaran (${x.payments.length})</summary>${x.payments.length ? x.payments.slice().reverse().map(p => `<div class="paymentrow"><div class="row"><b>${esc(name(p.member))} · ${fmt(p.amount)}</b><span class="status ${p.status === 'SETTLED' ? 'ok' : p.status === 'PENDING' ? 'pending' : 'rejected'}">${p.status === 'SETTLED' ? 'DITERIMA' : p.status === 'PENDING' ? 'MENUNGGU' : 'DITOLAK'}</span></div><small>${esc(p.date)} · ${esc(p.method)}</small>${p.status === 'PENDING' && active === x.owner ? `<div class="buttons" style="margin-top:6px">${btn('Terima', 'approve', 'primary', `data-kind="${kind}" data-id="${esc(x.id)}" data-pay="${esc(p.id)}"`)}${btn('Tolak', 'reject', '', `data-kind="${kind}" data-id="${esc(x.id)}" data-pay="${esc(p.id)}"`)}</div>` : ''}</div>`).join('') : '<p class="hint">Belum ada pembayaran.</p>'}</details>`;
}

function renderTal() {
  const t = current('tal');
  return `<div class="columns"><section class="glass panel">${heading('BAGIAN 01 · PENALANG', 'Siapa yang menalangi?', btn('+ Talangan', 'newTal', 'primary'))}${selector('tal')}${t ? `<div class="well"><div class="eyebrow">DATA PENALANG</div><h3>${esc(name(t.owner))}</h3><p class="note">${esc(t.date)} · ${esc(t.note || 'Belanja bersama')}</p><div class="line"></div><div class="row"><small>Total ditalangi</small><strong class="amount">${fmt(t.total)}</strong></div><p class="tally">${distribution(t.total, db.members.length)}</p><p class="tally">Bagian penalang sendiri: ${fmt(due(db, t, 'tal', t.owner))}. Harus diganti anggota lain: ${fmt(t.total - due(db, t, 'tal', t.owner))}.</p></div>` : empty('♧', 'Belum ada talangan', 'Catat belanja pertama. Data dimulai dari nol agar tidak tercampur dengan contoh.')}</section><section class="glass panel stack">${heading('BAGIAN 02 · GANTI TALANGAN', t ? 'Bayar ke ' + esc(name(t.owner)) : 'Pembayaran anggota')}${t ? paymentForm('tal', t) + `<div>${membersList('tal', t)}</div>` + history('tal', t) : empty('✓', 'Semua dimulai dari catatan', 'Buat talangan untuk melihat pembagian dan status pembayaran.')}</section></div>`;
}

function renderPool() {
  const p = current('pool');
  const collected = p ? p.payments.filter(x => x.status === 'SETTLED').reduce((a, x) => a + x.amount, 0) : 0;
  return `<div class="columns"><section class="glass panel stack">${heading('BAGIAN 01 · KUMPUL DANA', 'Setor sebelum belanja', btn('+ Kumpul Baru', 'newPool', 'purplebtn'))}<div>${selector('pool')}</div>${p ? (p.closed ? '' : paymentForm('pool', p)) + `<div>${membersList('pool', p)}</div>` + history('pool', p) : empty('♧', 'Belum ada kumpul dana', 'Buat rencana belanja dan tentukan nominal setoran per anggota.')}</section><section class="glass panel stack">${heading('BAGIAN 02 · REALISASI', 'Belanja & sisa kembalian')}${p ? `<div class="stats"><div class="well"><small>Terkumpul</small><b class="amount">${fmt(collected)}</b></div><div class="well"><small>Belanja toko</small><b class="amount">${p.spent === null ? 'Belum dicatat' : fmt(p.spent)}</b></div><div class="well"><small>${p.closed ? 'Dana dialokasikan' : 'Saldo tersedia'}</small><b class="amount">${fmt(p.closed ? p.closed.amount : collected - (p.spent ?? 0))}</b></div></div>${p.closed ? `<div class="well"><span class="status ok">DANA SUDAH DITUTUP</span><p class="note">${p.closed.action === 'transfer' ? 'Dialokasikan ke ' + esc(db.programs.find(x => x.id === p.closed.target)?.title ?? 'tabungan') : 'Pengembalian tunai dicatat pengelola'} pada ${esc(p.closed.date)}.</p><p class="tally">${distribution(p.closed.amount, 6)}</p><p class="hint">Realisasi dan alokasi dikunci untuk mencegah pencatatan ganda.</p></div>` : `<form id="spentForm" data-id="${esc(p.id)}" class="well stack">${field('Total belanja riil (MAD)', 'spent', 'number', p.spent === null ? '' : (p.spent / 100).toFixed(2), 'required min="0" step="0.01" max="1000000000"')}<button class="purplebtn wide" type="submit" ${active === p.owner ? '' : 'disabled'}>Simpan realisasi</button><p class="hint">Hanya ${esc(name(p.owner))} sebagai pengelola yang dapat mencatat realisasi.</p></form><div class="card stack"><h3>Tentukan sisa uang</h3><p class="note">Setelah semua setoran diterima dan belanja dicatat, sisa uang bisa dikembalikan atau dialokasikan ke tabungan. Proses ini hanya bisa dilakukan sekali.</p>${btn('Alokasikan / kembalikan sisa', 'finishPool', 'primary wide', active === p.owner ? '' : 'disabled')}</div>`}` : empty('≋', 'Realisasi belum tersedia', 'Pilih atau buat kumpul dana terlebih dahulu.')}</section></div>`;
}

function renderLt() {
  const x = current('lt');
  return `<section class="glass panel stack">${heading('TABUNGAN KOLEKTIF', 'Rencana besar, langkah kecil.', btn('+ Target Baru', 'newLt', 'primary'))}<div class="programs">${db.programs.map(p => {
    const saved = p.payments.filter(t => t.status === 'SETTLED').reduce((s, t) => s + t.amount, 0), pct = Math.min(100, Math.floor(saved / (p.target * 6) * 100));
    return btn(`<div class="row"><strong>${esc(p.title)}</strong><span class="amount">${pct}%</span></div><div class="progress"><div style="width:${pct}%"></div></div><small>${fmt(saved)} / ${fmt(p.target * 6)}<br>Target ${esc(p.deadline)}</small>`, 'select', 'selector ' + (p.id === x?.id ? 'selected' : ''), `data-kind="lt" data-id="${esc(p.id)}"`);
  }).join('')}</div>${x ? `<div class="well"><div class="row"><div><h2>${esc(x.title)}</h2><p class="note">Bendahara: ${esc(name(x.owner))} · ${esc(x.note)}</p></div><span class="amount">Target ${fmt(x.target)} / orang</span></div></div>${paymentForm('lt', x)}<div class="members">${db.members.map(m => {
    const v = paid(x, m.id), p = paid(x, m.id, 'PENDING'), pct = Math.min(100, Math.floor(v / x.target * 100));
    return `<div class="card"><div class="row"><b>${esc(m.name)}</b><strong class="amount">${pct}%</strong></div><div class="progress"><div style="width:${pct}%"></div></div><small>Tabungan ${fmt(v)} · Kurang ${fmt(Math.max(0, x.target - v))}</small>${p ? `<p class="hint">Menunggu: ${fmt(p)}</p>` : ''}${v > x.target ? `<p class="hint">Melebihi target: ${fmt(v - x.target)}</p>` : ''}</div>`;
  }).join('')}</div>${history('lt', x)}` : empty('✧', 'Mulai rencana bersama', 'Umroh, liburan, tiket pulang, atau dana bersama lainnya. Tentukan target dan bendaharanya.', btn('+ Buat Target Pertama', 'newLt', 'primary'))}</section>`;
}

function pending() {
  return ['tal', 'pool', 'lt'].flatMap(kind => collection(kind).flatMap(item => item.payments.filter(p => p.status === 'PENDING').map(p => ({kind, item, p}))));
}

function renderConfirm() {
  const list = pending();
  return `<section class="glass panel">${heading('VERIFIKASI PENERIMA', 'Konfirmasi uang masuk')}<p class="note">Uang menunggu tidak menambah saldo diterima. Hanya pencatat yang dipilih sebagai penerima dapat mengonfirmasi.</p><div class="confirmcards">${list.length ? list.map(({kind, item, p}) => `<div class="card"><div class="eyebrow">${esc(item.title)}</div><div class="row"><h3>${esc(name(p.member))} → ${esc(name(item.owner))}</h3><span class="amount">${fmt(p.amount)}</span></div><p class="note">${esc(p.date)} · ${esc(p.method)}</p>${active === item.owner ? `<div class="buttons">${btn('✓ Terima Uang', 'approve', 'primary', `data-kind="${kind}" data-id="${esc(item.id)}" data-pay="${esc(p.id)}"`)}${btn('Tolak', 'reject', '', `data-kind="${kind}" data-id="${esc(item.id)}" data-pay="${esc(p.id)}"`)}</div>` : `<p class="hint">Menunggu ${esc(name(item.owner))}. Pilih penerima pada menu Pencatat untuk memproses.</p>`}</div>`).join('') : empty('✓', 'Tidak ada antrean', 'Semua pembayaran yang diajukan sudah diproses, atau belum ada pengajuan baru.')}</div></section>`;
}

function newForm(kind, values = {}) {
  const title = kind === 'tal' ? 'Catat Talangan Baru' : kind === 'pool' ? 'Kumpul Dana Baru' : 'Target Iuran Berjangka';
  modal(`<h2>${title}</h2><form id="newForm" data-kind="${kind}" class="formgrid">${field('Nama / tujuan', 'title', 'text', values.title || '', 'required maxlength="120"')}${select(kind === 'tal' ? 'Siapa yang menalangi?' : 'Pengelola / bendahara', 'owner', options(active))}${field(kind === 'tal' ? 'Total ditalangi (MAD)' : 'Target per orang (MAD)', 'amount', 'number', values.amount || '', 'required min="0.01" max="1000000000" step="0.01"')}${kind === 'tal' ? field('Tanggal belanja', 'date', 'date', today(), 'required') : kind === 'lt' ? field('Target tanggal', 'deadline', 'date', '', 'required') : ''}${kind !== 'pool' ? field('Rincian / catatan', 'note', 'text', values.note || '', 'maxlength="500"') : ''}<p class="hint full">${kind === 'tal' ? 'Dibagi ke 6 anggota dengan presisi sen. Bagian penalang dianggap dibayar sendiri.' : 'Saldo dimulai dari nol. Setoran dicatat dan dikonfirmasi secara terpisah.'}</p><button class="primary full" type="submit">Simpan</button></form>`);
}

function renderOther() {
  return `<section class="glass panel stack"><h2>Lainnya</h2>
    <div class="well stack"><h3>Backup & Pemulihan</h3><p class="note">Unduh seluruh catatan sebagai file JSON. Gunakan file ini untuk memulihkan data atau memindahkannya ke browser lain.</p>
    ${btn('Unduh Backup JSON', 'export', 'primary wide')}${btn('Pulihkan Backup JSON', 'import', 'wide')}</div>
    <div class="well stack"><h3>Reset Data</h3><p class="note">Hapus semua transaksi, patungan, iuran, pinjaman uang dan barang, riwayat kalkulator, serta data demo dari browser ini. Saldo kembali nol. Daftar anggota tetap tersedia.</p>
    ${btn('Reset Semua Data', 'resetData', 'dangerbtn wide')}</div></section>`;
}

function resetAllData() {
  if (storageBlocked || readOnly) throw Error('Muat ulang halaman sebelum mereset data.');
  const stored = localStorage.getItem(key);
  if (stored && JSON.parse(stored).revision !== db.revision) throw Error('Data berubah di tab lain. Muat ulang sebelum mereset.');
  const clean = fresh();
  clean.members = structuredClone(db.members);
  clean.revision = db.revision + 1;
  initFinance(clean);
  validate(clean);
  validateFinance(clean);
  // Simpan database kosong, bukan menghapus key, agar demo tidak muncul kembali.
  // Jangan memakai transact: audit perubahan akan menyimpan ulang data yang dihapus.
  localStorage.setItem(key, JSON.stringify(clean));
  db = clean;
  selected = {tal: null, pool: null, lt: null};
  financeMonth = ''; financeFilter = 'all';
  pendingImportData = null; lastSaved = null;
  expr = '0'; people = 6; calcLabel = ''; just = false; cash = '';
  $('#importFile').value = '';
  close(); render();
  toast('Semua data termasuk demo dihapus. Saldo kembali nol.');
}

function download(data, file) {
  const u = URL.createObjectURL(new Blob([data], {type: 'application/json'}));
  const a = document.createElement('a');
  a.href = u;
  a.download = file;
  a.click();
  setTimeout(() => URL.revokeObjectURL(u), 1000);
}

function seedKasDemo() {
  const d = today();
  transact(() => {
    const f = initFinance(db);
    if (f.entries.length || f.items.length) return;
    recordFinance(db, {member: 'm1', date: d, deadline: '', category: 'Umum', ref: '', type: 'deposit', account: 'cash', amount: 120000, note: 'Iuran Kas Bulanan (6 Anggota × 200 MAD)'}, active);
    recordFinance(db, {member: 'm2', date: d, deadline: '', category: 'Umum', ref: '', type: 'deposit', account: 'bank', amount: 60000, note: 'Saldo Cadangan Kas Digital CIH'}, active);
    recordFinance(db, {member: 'm1', date: d, deadline: '', category: 'Umum', ref: '', type: 'expense', account: 'bank', amount: 24900, note: 'Tagihan WiFi Maroc Telecom'}, active);
    recordFinance(db, {member: 'm3', date: d, deadline: '', category: 'Umum', ref: '', type: 'expense', account: 'cash', amount: 18500, note: 'Isi Ulang Tabung Gas & Sabun Cuci Piring'}, active);
    recordFinance(db, {member: 'm5', date: d, deadline: '', category: 'Umum', ref: '', type: 'loan', account: 'cash', amount: 15000, note: 'Pinjam tunai bayar kurir paket'}, active);
    f.items.push(
      {id: uid(), name: 'Setrika Uap Philips', condition: 'Dicatat', borrower: 'm4', deadline: d, history: [{at: new Date().toISOString(), action: 'Dipinjam', member: 'm4', condition: 'Dicatat', actor: active}]},
      {id: uid(), name: 'Kabel Roll Panjang 10m', condition: 'Dicatat', borrower: null, deadline: null, history: [{at: new Date().toISOString(), action: 'Dikembalikan', member: 'm1', condition: 'Dicatat', actor: active}]}
    );
  });
  render();
  toast('Contoh data Kas Dar Marrakesh berhasil dimuat.');
}

async function action(a, b) {
  switch (a) {
    case 'editProfile':
      modal(`<h2>Foto Profil</h2><p>Pilih foto untuk Brankas Marrakesh Boy. Foto dipotong persegi dari bagian tengah dan disimpan di browser ini, serta ikut dalam backup.</p><div class="stack">${btn('Pilih Foto', 'chooseProfile', 'primary wide')}${db.profilePhoto ? btn('Hapus Foto', 'removeProfile', 'wide') : ''}</div>`);
      break;
    case 'chooseProfile': $('#profileFile').click(); break;
    case 'removeProfile':
      transact(() => { delete db.profilePhoto; });
      close(); render(); toast('Foto dihapus. Ikon salju digunakan kembali.');
      break;
    case 'toggleFx': {
      fxEnabled = !fxEnabled;
      const btnEl = document.getElementById('fxToggle');
      if (btnEl) btnEl.textContent = fxEnabled ? '❄️ Salju: ON' : '❄️ Salju: OFF';
      startSnow();
      toast(fxEnabled ? 'Animasi kristal salju diaktifkan.' : 'Animasi kristal salju dijeda.');
      break;
    }
    case 'switchMember': {
      active = b.dataset.member || active;
      render();
      toast('Pencatat aktif: ' + name(active));
      break;
    }
    case 'openCalc': tab = 'kalkulator'; render(); break;
    case 'pathTal': path = 'tal'; render(); break;
    case 'pathPool': path = 'pool'; render(); break;
    case 'newTal': newForm('tal'); break;
    case 'newPool': newForm('pool'); break;
    case 'newLt': newForm('lt'); break;
    case 'select': selected[b.dataset.kind] = b.dataset.id; render(); break;
    case 'filterKas': financeFilter = b.dataset.filter || 'all'; render(); break;
    case 'kasPreset': {
      const noteInput = document.querySelector('#financeEntry input[name="note"]');
      if (noteInput) {
        noteInput.value = b.dataset.note || '';
        noteInput.focus();
      }
      break;
    }
    case 'seedKasDemo': seedKasDemo(); break;
    case 'key': input(b.dataset.value); break;
    case 'clear': expr = '0'; just = false; updateCalc(); break;
    case 'back': expr = expr.slice(0, -1) || '0'; just = false; updateCalc(); break;
    case 'equals': calcValue(); just = true; updateCalc(); break;
    case 'less': people = Math.max(1, people - 1); render(); break;
    case 'more': people = Math.min(20, people + 1); render(); break;
    case 'divide': expr = `(${expr})/${people}`; calcValue(); people = 1; just = true; render(); toast('Hasil bagi dimuat. Pembagi diatur ke 1 agar tidak dibagi dua kali.'); break;
    case 'example': expr = '15+3+4+2+4.5'; calcLabel = 'Masak Telur Baladi (5 Barang)'; people = 6; just = true; render(); break;
    case 'saveTape': saveTape(); break;
    case 'loadTape': {
      const t = db.tape.find(x => x.id === b.dataset.id);
      expr = t.expr; people = t.people; calcLabel = t.label; just = true; render();
      break;
    }
    case 'deleteTape': transact(() => db.tape = db.tape.filter(t => t.id !== b.dataset.id)); lastSaved = null; render(); break;
    case 'clearTape':
      modal(`<h2>Hapus Riwayat Kalkulator?</h2><p>Semua catatan pita kalkulator akan dihapus dari penyimpanan lokal.</p><div class="buttons">${btn('Ya, Hapus Semua', 'confirmClearTape', 'dangerbtn')}${btn('Batal', 'closeModal', '')}</div>`);
      break;
    case 'confirmClearTape':
      transact(() => db.tape = []); lastSaved = null; close(); render(); toast('Pita kalkulator dibersihkan.');
      break;
    case 'closeModal': close(); break;
    case 'sumTape': expr = String(db.tape.reduce((a, t) => a + t.result, 0)); just = true; render(); break;
    case 'toTal': {
      const c = calcCents();
      newForm('tal', {title: calcLabel || 'Belanja Hasil Kalkulator', amount: (c / 100).toFixed(2), note: 'Hitungan: ' + expr});
      break;
    }
    case 'toPool': {
      const c = calcCents();
      if (!db.pools.some(p => !p.closed && p.owner === active)) throw Error('Buat kumpul dana dahulu atau pilih pengelolanya sebagai pencatat.');
      modal(`<h2>Pakai sebagai realisasi belanja</h2><p>Total ${fmt(c)}. Pilih dana yang ingin diperbarui.</p><form id="calcPoolForm" class="stack">${select('Kumpul dana', 'poolId', db.pools.filter(p => !p.closed && p.owner === active).map(p => `<option value="${esc(p.id)}">${esc(p.title)}</option>`).join(''))}<button class="primary wide" type="submit">Simpan realisasi ${fmt(c)}</button></form>`);
      break;
    }
    case 'approve':
    case 'reject': {
      const x = collection(b.dataset.kind).find(x => x.id === b.dataset.id);
      transact(() => confirmPayment(x, b.dataset.pay, a, active));
      render();
      toast(a === 'approve' ? 'Uang diterima. Status tagihan dihitung ulang.' : 'Pembayaran ditolak.');
      break;
    }
    case 'finishPool': {
      const p = current('pool');
      if (!p || p.owner !== active) throw Error('Hanya pengelola yang dapat memproses.');
      if (p.closed) throw Error('Sudah diproses.');
      if (p.spent === null || db.members.some(m => paid(p, m.id) !== p.target) || p.payments.some(t => t.status === 'PENDING')) throw Error('Lengkapi semua setoran dan realisasi terlebih dahulu.');
      const surplus = p.target * 6 - p.spent;
      if (surplus < 0) throw Error('Belanja melebihi dana. Koreksi realisasi atau catat selisih sebagai talangan.');
      modal(`<h2>Alokasi Sisa Dana</h2><p>${esc(p.title)} · ${fmt(surplus)}<br>${distribution(surplus, 6)}</p><form id="finishForm" data-id="${esc(p.id)}" class="stack">${select('Tindakan', 'disposition', '<option value="refund">Sudah dikembalikan tunai ke anggota</option><option value="transfer">Alokasikan ke tabungan</option>')}${select('Target tabungan (untuk alokasi)', 'destination', '<option value="">Pilih target</option>' + db.programs.map(x => `<option value="${esc(x.id)}">${esc(x.title)}</option>`).join(''))}<p class="hint">Pastikan uang telah dikembalikan atau diserahkan. Catatan dana akan dikunci. Jika bendahara tujuan berbeda, alokasi menunggu konfirmasinya.</p><button class="primary wide" type="submit">Konfirmasi & tutup dana</button></form>`);
      break;
    }
    case 'resetData':
      modal(`<h2>Reset semua data?</h2><p>Semua catatan dan data demo di browser ini akan dihapus permanen. Unduh backup terlebih dahulu jika masih diperlukan.</p><div class="stack">${btn('Unduh Backup JSON', 'export', 'wide')}${field('Ketik RESET untuk melanjutkan', 'resetConfirmation', 'text', '', 'autocomplete="off"')}${btn('Hapus Semua Data', 'confirmReset', 'dangerbtn wide')}${btn('Batal', 'closeModal', 'wide')}</div>`);
      break;
    case 'confirmReset':
      if ($('#resetConfirmation')?.value !== 'RESET') throw Error('Ketik RESET untuk mengonfirmasi.');
      resetAllData();
      break;
    case 'export': download(JSON.stringify(db, null, 2), 'Marrakesh-Backup-' + today() + '.json'); break;
    case 'import': $('#importFile').click(); break;
    case 'confirmImport': {
      if (!pendingImportData) return;
      if (storageBlocked) throw Error('Data lokal tidak bisa dibaca. Ekspor cadangan mentah sebelum pemulihan.');
      transact(() => {
        const rev = db.revision;
        db = structuredClone(pendingImportData);
        db.revision = rev;
      });
      pendingImportData = null;
      selected = {tal: null, pool: null, lt: null};
      active = db.members[0].id;
      lastSaved = null;
      close();
      render();
      toast('Backup berhasil dipulihkan.');
      break;
    }
  }
}

document.addEventListener('click', e => {
  const t = e.target.closest('[data-tab]');
  if (t) {
    tab = t.dataset.tab;
    render();
    return;
  }
  const b = e.target.closest('[data-action]');
  if (b) Promise.resolve(action(b.dataset.action, b)).catch(e => toast(e.message));
});

document.addEventListener('submit', e => {
  e.preventDefault();
  const f = e.target, v = Object.fromEntries(new FormData(f));
  try {
    if (f.id.startsWith('finance') || f.dataset.financeItem) {
      transact(() => submitFinance(db, f, v, active));
      render();
      toast('Catatan kas tersimpan.');
    } else if (f.id === 'newForm') {
      const k = f.dataset.kind;
      if (!v.title.trim()) throw Error('Nama wajib diisi.');
      const amount = money(v.amount);
      if (k === 'tal' && !validDate(v.date) || k === 'lt' && !validDate(v.deadline)) throw Error('Tanggal tidak valid.');
      const x = {id: uid(), title: v.title.trim(), owner: v.owner, payments: []};
      if (k === 'tal') {
        Object.assign(x, {total: amount, date: v.date, note: v.note.trim()});
        const own = shares(amount, 6)[db.members.findIndex(m => m.id === x.owner)];
        if (own) x.payments.push({id: uid(), member: x.owner, amount: own, date: v.date, method: 'Bagian sendiri · bayar toko', status: 'SETTLED'});
      } else if (k === 'pool') Object.assign(x, {target: amount, spent: null, closed: null});
      else Object.assign(x, {target: amount, deadline: v.deadline, note: v.note.trim()});
      transact(() => collection(k).unshift(x));
      selected[k] = x.id;
      tab = k === 'lt' ? 'jangka' : 'belanja';
      path = k === 'pool' ? 'pool' : 'tal';
      close();
      render();
      toast('Catatan baru tersimpan.');
    } else if (f.id === 'paymentForm') {
      const k = f.dataset.kind, x = collection(k).find(x => x.id === f.dataset.id);
      transact(() => addPayment(db, x, k, v.payMember, money(v.payAmount), v.payDate, v.payMethod, active));
      render();
      toast(active === x.owner ? 'Uang masuk dicatat.' : 'Pembayaran diajukan untuk konfirmasi.');
    } else if (f.id === 'spentForm' || f.id === 'calcPoolForm') {
      const p = db.pools.find(p => p.id === (f.id === 'spentForm' ? f.dataset.id : v.poolId));
      if (!p || p.owner !== active || p.closed) throw Error('Dana tidak bisa diperbarui oleh pencatat ini.');
      const c = f.id === 'calcPoolForm' ? calcCents() : Number(v.spent) === 0 ? 0 : money(v.spent);
      transact(() => p.spent = c);
      if (f.id === 'calcPoolForm') {
        selected.pool = p.id;
        path = 'pool';
        tab = 'belanja';
        close();
      }
      render();
      toast('Realisasi tersimpan.');
    } else if (f.id === 'finishForm') {
      const p = db.pools.find(p => p.id === f.dataset.id);
      transact(() => finishPool(db, p, v.disposition, v.destination, active, today()));
      close();
      render();
      toast('Dana ditutup. Alokasi tersimpan satu kali.');
    }
  } catch (err) {
    toast(err.message);
  }
});

document.addEventListener('input', e => {
  if (e.target.id === 'calcLabel') calcLabel = e.target.value;
  if (e.target.id === 'cash') { cash = e.target.value; updateCalc(); }
});

document.addEventListener('change', e => {
  if (e.target.id === 'financeMonth') {
    financeMonth = e.target.value;
    render();
  }
  if (e.target.id === 'payMember') {
    const f = e.target.form, k = f.dataset.kind, x = collection(k).find(x => x.id === f.dataset.id);
    if (k !== 'lt') $('#payAmount').value = ((due(db, x, k, e.target.value) - paid(x, e.target.value) - paid(x, e.target.value, 'PENDING')) / 100).toFixed(2);
  }
});

$('#activeUser').onchange = e => { active = e.target.value; render(); };
$('#close').onclick = close;
$('#help').onclick = () => modal('<h2>Mode pencatat lokal</h2><p>Pilihan anggota membantu mencatat siapa yang membayar dan siapa yang menerima. Ini bukan autentikasi: orang yang memegang browser bisa mengganti anggota.</p><p>Data hanya tersimpan di browser dan alamat website ini. Belum ada sinkronisasi antar-HP. Gunakan backup untuk memindahkan data. Saldo tabungan dan status lunas hanya menghitung pembayaran yang diterima.</p>');

try {
  const savedTheme = localStorage.getItem('mf-theme');
  const isDark = savedTheme === 'dark';
  document.documentElement.classList.toggle('dark', isDark);
  document.documentElement.classList.toggle('light', !isDark);
  $('#theme').textContent = isDark ? '☀' : '☾';
} catch {}

$('#theme').onclick = () => {
  const light = document.documentElement.classList.toggle('light');
  document.documentElement.classList.toggle('dark', !light);
  try {
    localStorage.setItem('mf-theme', light ? 'light' : 'dark');
  } catch {}
  $('#theme').textContent = light ? '☾' : '☀';
};

$('#importFile').onchange = async e => {
  const file = e.target.files[0];
  try {
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) throw Error('Backup maksimal 10 MB.');
    const imported = validate(JSON.parse(await file.text()));
    validateFinance(imported);
    pendingImportData = imported;
    modal(`<h2>Pulihkan Backup JSON?</h2><p>Data lokal saat ini akan diganti dengan isi berkas backup. Pastikan lu sudah mengunduh cadangan terbaru bila masih diperlukan.</p><div class="buttons">${btn('✓ Pulihkan Sekarang', 'confirmImport', 'primary')}${btn('Batal', 'closeModal', '')}</div>`);
  } catch (err) {
    toast(err.message);
  } finally {
    e.target.value = '';
  }
};

window.addEventListener('storage', e => {
  if (e.key === key) {
    readOnly = true;
    $('#saveStatus').textContent = 'Data berubah di tab lain — muat ulang';
    toast('Data berubah di tab lain. Muat ulang sebelum mencatat lagi.');
  }
});

document.addEventListener('keydown', e => {
  if (tab !== 'kalkulator' || $('#modal').open || e.ctrlKey || e.metaKey || e.altKey || ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName) || (document.activeElement?.tagName === 'BUTTON' && (e.key === 'Enter' || e.key === ' '))) return;
  try {
    if (/^[0-9+\-*/().%]$/.test(e.key) || e.key === ',') {
      e.preventDefault();
      input(e.key === ',' ? '.' : e.key);
    } else if (e.key === 'Enter' || e.key === '=') {
      e.preventDefault();
      calcValue();
      just = true;
      updateCalc();
    } else if (e.key === 'Backspace') {
      e.preventDefault();
      expr = expr.slice(0, -1) || '0';
      just = false;
      updateCalc();
    } else if (e.key === 'Escape') {
      expr = '0';
      just = false;
      updateCalc();
    }
  } catch (err) {
    toast(err.message);
  }
});

window.addEventListener('hashchange', () => {
  if (location.hash === '#kalkulator') { tab = 'kalkulator'; render(); }
  if (location.hash === '#lainnya') { tab = 'lainnya'; render(); }
  if (location.hash === '#kas') { tab = 'kas'; render(); }
  if (location.hash === '#belanja') { tab = 'belanja'; render(); }
});

if (location.hash === '#kalkulator') tab = 'kalkulator';
else if (location.hash === '#belanja') tab = 'belanja';
else if (location.hash === '#lainnya') tab = 'lainnya';
render();

if (storageBlocked) {
  $('#saveStatus').textContent = 'Penyimpanan tidak dapat dibaca — data tidak ditimpa';
  toast('Penyimpanan tidak tersedia atau data rusak. Jangan masukkan transaksi baru.');
}

// --- MESIN ANIMASI KRISTAL SALJU MUSIM DINGIN (WINTER SNOWFALL) ---
function startSnow() {
  const canvas = document.getElementById('fxCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  if (fxRaf) {
    cancelAnimationFrame(fxRaf);
    fxRaf = null;
  }
  const resize = () => {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  };
  resize();
  window.onresize = resize;

  if (!fxEnabled) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    return;
  }

  const count = 42;
  const flakes = Array.from({length: count}, () => ({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    r: 4 + Math.random() * 6.5,
    vy: 0.55 + Math.random() * 1.15,
    angle: Math.random() * Math.PI * 2,
    spin: (Math.random() - 0.5) * 0.02,
    alpha: 0.55 + Math.random() * 0.4,
    crystal: Math.random() > 0.35
  }));

  function drawFrame() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const isDark = document.documentElement.classList.contains('dark');

    for (const pt of flakes) {
      pt.y += pt.vy;
      pt.x += Math.cos(pt.angle) * 0.5;
      pt.angle += pt.spin;
      if (pt.y > canvas.height + 16) {
        pt.y = -12;
        pt.x = Math.random() * canvas.width;
      }

      ctx.save();
      ctx.globalAlpha = pt.alpha;
      ctx.translate(pt.x, pt.y);
      ctx.rotate(pt.angle);

      if (pt.crystal) {
        // Kristal Salju 6-Sisi yang Tegas & Jelas
        ctx.strokeStyle = isDark ? '#7dd3fc' : '#0284c7';
        ctx.lineWidth = 1.8;
        for (let k = 0; k < 3; k++) {
          ctx.beginPath();
          ctx.moveTo(-pt.r, 0);
          ctx.lineTo(pt.r, 0);
          ctx.stroke();
          ctx.rotate(Math.PI / 3);
        }
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(0, 0, 1.8, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Butiran Salju Bulat Halus dengan Kontur
        ctx.fillStyle = '#ffffff';
        ctx.strokeStyle = isDark ? '#38bdf8' : '#0284c7';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(0, 0, pt.r * 0.55, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
      ctx.restore();
    }
    fxRaf = requestAnimationFrame(drawFrame);
  }
  fxRaf = requestAnimationFrame(drawFrame);
}
startSnow();

$('#profileFile').onchange = async e => {
  const file = e.target.files?.[0];
  if (!file) return;
  let url;
  try {
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) throw Error('Pilih foto JPG, PNG, atau WebP.');
    if (file.size > 10 * 1024 * 1024) throw Error('Ukuran foto maksimal 10 MB.');
    url = URL.createObjectURL(file);
    const img = new Image();
    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = () => reject(Error('Foto tidak dapat dibaca. Pilih foto lain.'));
      img.src = url;
    });
    const side = Math.min(img.naturalWidth, img.naturalHeight);
    if (!side) throw Error('Foto tidak valid.');
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = 384;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#cfe7ff'; ctx.fillRect(0, 0, 384, 384);
    ctx.drawImage(img, (img.naturalWidth - side) / 2, (img.naturalHeight - side) / 2, side, side, 0, 0, 384, 384);
    const photo = canvas.toDataURL('image/jpeg', 0.85);
    transact(() => { db.profilePhoto = photo; });
    close(); render(); toast('Foto profil berhasil diganti.');
  } catch (err) { toast(err.message); }
  finally { if (url) URL.revokeObjectURL(url); e.target.value = ''; }
};
