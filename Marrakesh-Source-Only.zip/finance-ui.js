import {init, totals, remaining, record} from './finance.js';
import {money, uid} from './core.js';

export function financeUI(c) {
  const {db, active, esc, fmt, name, field, select, options, btn, today} = c;
  const f = init(db);
  const s = totals(db);
  const month = c.month || today().slice(0, 7);
  const filter = c.filter || 'all';

  const allLoans = f.entries.filter(e => e.type === 'loan');
  const activeLoans = allLoans.filter(e => remaining(db, e.id) > 0);
  const settledLoans = allLoans.filter(e => remaining(db, e.id) <= 0);

  const borrowedItems = f.items.filter(i => Boolean(i.borrower));
  const availableItems = f.items.filter(i => !i.borrower);

  const labels = {
    deposit: 'Uang Masuk',
    expense: 'Uang Keluar',
    loan: 'Pinjaman Kas',
    repay: 'Pelunasan Pinjaman',
    advance: 'Talangan Lama',
    reimburse: 'Ganti Talangan',
    reserve: 'Alokasi Dana',
    release: 'Pelepasan Alokasi'
  };

  // Transaksi pada bulan terpilih
  const monthEntries = f.entries.filter(e => e.date.startsWith(month)).slice().reverse();

  // Ringkasan Arus Kas Bulanan (Masuk vs Keluar vs Pinjaman)
  let monthIn = 0;
  let monthOut = 0;
  let monthLoanOut = 0;
  let monthCashVol = 0;
  let monthBankVol = 0;

  for (const e of monthEntries) {
    if (e.type === 'deposit' || e.type === 'repay') monthIn += e.amount;
    if (e.type === 'expense' || e.type === 'reimburse') monthOut += e.amount;
    if (e.type === 'loan') monthLoanOut += e.amount;
    if (e.account === 'cash') monthCashVol += e.amount;
    if (e.account === 'bank') monthBankVol += e.amount;
  }

  const monthNet = monthIn - (monthOut + monthLoanOut);
  const totalVolume = monthIn + monthOut + monthLoanOut;
  const inPct = totalVolume > 0 ? Math.round((monthIn / totalVolume) * 100) : 50;

  // Perhitungan Grafik Donat: Porsi Cash vs Digital vs Piutang Dipinjam
  const assetCash = Math.max(0, s.cash);
  const assetBank = Math.max(0, s.bank);
  const assetDebt = Math.max(0, s.debt);
  const totalManaged = assetCash + assetBank + assetDebt;

  const pctCash = totalManaged > 0 ? Math.round((assetCash / totalManaged) * 100) : 0;
  const pctBank = totalManaged > 0 ? Math.round((assetBank / totalManaged) * 100) : 0;
  const pctDebt = totalManaged > 0 ? Math.max(0, 100 - pctCash - pctBank) : 0;

  // SVG Donut Math (r = 54, circumference = 2 * pi * 54 = 339.292)
  const C = 339.292;
  const lenCash = totalManaged > 0 ? (assetCash / totalManaged) * C : 0;
  const lenBank = totalManaged > 0 ? (assetBank / totalManaged) * C : 0;
  const lenDebt = totalManaged > 0 ? (assetDebt / totalManaged) * C : 0;

  const offCash = 0;
  const offBank = -lenCash;
  const offDebt = -(lenCash + lenBank);

  // Perhitungan Grafik Batang Arus Kas Bulanan
  const maxBar = Math.max(monthIn, monthOut, monthLoanOut, 1);
  const barInPct = Math.round((monthIn / maxBar) * 100);
  const barOutPct = Math.round((monthOut / maxBar) * 100);
  const barLoanPct = Math.round((monthLoanOut / maxBar) * 100);

  const totalAccVol = monthCashVol + monthBankVol;
  const cashVolPct = totalAccVol > 0 ? Math.round((monthCashVol / totalAccVol) * 100) : 50;
  const bankVolPct = totalAccVol > 0 ? 100 - cashVolPct : 50;

  // Hitung jumlah per filter pada bulan terpilih
  const counts = {
    all: monthEntries.length,
    in: monthEntries.filter(e => e.type === 'deposit' || e.type === 'repay').length,
    out: monthEntries.filter(e => e.type === 'expense' || e.type === 'reimburse').length,
    loan: monthEntries.filter(e => e.type === 'loan' || e.type === 'repay').length,
    cash: monthEntries.filter(e => e.account === 'cash').length,
    bank: monthEntries.filter(e => e.account === 'bank').length
  };

  const filteredEntries = monthEntries.filter(e => {
    if (filter === 'in') return e.type === 'deposit' || e.type === 'repay';
    if (filter === 'out') return e.type === 'expense' || e.type === 'reimburse';
    if (filter === 'loan') return e.type === 'loan' || e.type === 'repay';
    if (filter === 'cash') return e.account === 'cash';
    if (filter === 'bank') return e.account === 'bank';
    return true;
  });

  const presets = [
    'Iuran Kas Bulanan',
    'WiFi Maroc Telecom',
    'Listrik & Air',
    'Gas & Dapur',
    'Perlengkapan Rumah'
  ];

  return `
  <div class="kas-layout">
    <!-- BAGIAN 1: BENTO RINGKASAN SALDO KAS & AKSI CEPAT -->
    <section class="glass panel stack">
      <div class="heading" style="margin-bottom:4px">
        <div>
          <h2>Ringkasan Kas & Likuiditas</h2>
        </div>
        ${!f.entries.length && !f.items.length
          ? btn('✦ Muat Contoh Data Kas', 'seedKasDemo', 'chip-btn')
          : `<span class="status ok">Pencatat Aktif: ${esc(name(active))}</span>`}
      </div>

      <div class="kas-bento">
        <div class="kas-hero-card">
          <div class="kas-hero-top">
            <div>
              <div class="eyebrow">TOTAL SALDO KAS AKTIF (CASH + DIGITAL)</div>
              <div class="kas-hero-balance">${fmt(s.total).replace(' MAD', '')}<span>MAD</span></div>
            </div>
            <span class="status ${s.free > 0 ? 'ok' : 'pending'}">
              Dana Bebas: ${fmt(s.free)}
            </span>
          </div>
          <div class="kas-hero-meta">
            <span class="kas-pill">
              <span class="dot"></span>
              Total Aset Kas (Termasuk Piutang): <b>${fmt(s.total + s.debt)}</b>
            </span>
            ${s.reserved ? `<span class="kas-pill">Alokasi Disimpan: <b>${fmt(s.reserved)}</b></span>` : ''}
            <span class="kas-pill">Pinjaman Aktif: <b>${activeLoans.length} catatan</b></span>
          </div>
        </div>

        <div class="kas-kpi-grid">
          <div class="kas-kpi">
            <div class="kas-kpi-head">
              <small>Kas Tunai (Cash)</small>
              <span class="kas-kpi-icon green">₵</span>
            </div>
            <div class="kas-kpi-value amount">${fmt(s.cash)}</div>
            <small class="hint">${pctCash}% dari total aset kas</small>
          </div>

          <div class="kas-kpi">
            <div class="kas-kpi-head">
              <small>Saldo Digital (Bank)</small>
              <span class="kas-kpi-icon purple">◈</span>
            </div>
            <div class="kas-kpi-value amount info">${fmt(s.bank)}</div>
            <small class="hint">${pctBank}% dari total aset kas</small>
          </div>

          <div class="kas-kpi span-2">
            <div>
              <small>Piutang Kas (Sedang Dipinjam Anggota)</small>
              <div class="kas-kpi-value amount ${s.debt > 0 ? 'warning' : ''}" style="margin-top:3px">${fmt(s.debt)}</div>
            </div>
            <div style="text-align:right">
              <span class="status ${activeLoans.length ? 'pending' : 'ok'}">${activeLoans.length} Pinjaman Uang</span>
              <span class="status ${borrowedItems.length ? 'info' : 'ok'}" style="margin-left:4px">${borrowedItems.length} Barang Dipinjam</span>
            </div>
          </div>
        </div>
      </div>

      <!-- PANEL ANALITIK VISUAL: GRAFIK DONAT PORSI KAS & GRAFIK BATANG ARUS KAS -->
      <div class="kas-charts-grid">
        <!-- GRAFIK 1: DONAT KOMPOSISI DANA KAS -->
        <div class="chart-card">
          <div class="chart-card-head">
            <div>
              <div class="eyebrow">KOMPOSISI DANA</div>
              <h3>Porsi Cash vs Digital vs Piutang</h3>
            </div>
            <span class="tx-tag">${totalManaged > 0 ? 'Aktif' : 'Kosong'}</span>
          </div>

          <div class="donut-layout">
            <div class="donut-wrap">
              <svg viewBox="0 0 160 160" class="donut-svg" role="img" aria-label="Grafik donat komposisi kas">
                <circle cx="80" cy="80" r="54" fill="none" stroke="var(--line)" stroke-width="20"></circle>
                ${totalManaged > 0 ? `
                  <circle cx="80" cy="80" r="54" fill="none" stroke="var(--green)" stroke-width="20"
                    stroke-dasharray="${lenCash.toFixed(2)} ${C.toFixed(2)}"
                    stroke-dashoffset="${offCash.toFixed(2)}"
                    transform="rotate(-90 80 80)"></circle>
                  <circle cx="80" cy="80" r="54" fill="none" stroke="var(--purple)" stroke-width="20"
                    stroke-dasharray="${lenBank.toFixed(2)} ${C.toFixed(2)}"
                    stroke-dashoffset="${offBank.toFixed(2)}"
                    transform="rotate(-90 80 80)"></circle>
                  <circle cx="80" cy="80" r="54" fill="none" stroke="var(--amber)" stroke-width="20"
                    stroke-dasharray="${lenDebt.toFixed(2)} ${C.toFixed(2)}"
                    stroke-dashoffset="${offDebt.toFixed(2)}"
                    transform="rotate(-90 80 80)"></circle>
                ` : ''}
              </svg>
              <div class="donut-center">
                <strong>${pctCash + pctBank}%</strong>
                <small>Likuid</small>
              </div>
            </div>

            <div class="donut-legend">
              <div class="legend-item">
                <span class="legend-swatch green-swatch"></span>
                <div class="legend-meta">
                  <div class="row"><b>Cash (Tunai)</b><span class="mono">${pctCash}%</span></div>
                  <small>${fmt(s.cash)}</small>
                </div>
              </div>
              <div class="legend-item">
                <span class="legend-swatch purple-swatch"></span>
                <div class="legend-meta">
                  <div class="row"><b>Digital (Bank)</b><span class="mono">${pctBank}%</span></div>
                  <small>${fmt(s.bank)}</small>
                </div>
              </div>
              <div class="legend-item">
                <span class="legend-swatch amber-swatch"></span>
                <div class="legend-meta">
                  <div class="row"><b>Piutang Anggota</b><span class="mono">${pctDebt}%</span></div>
                  <small>${fmt(s.debt)}</small>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- GRAFIK 2: BATANG PERBANDINGAN ARUS KAS BULANAN -->
        <div class="chart-card">
          <div class="chart-card-head">
            <div>
              <div class="eyebrow">GRAFIK ARUS KAS (${esc(month)})</div>
              <h3>Masuk vs Belanja vs Pinjaman</h3>
            </div>
            <span class="status ${monthNet >= 0 ? 'ok' : 'rejected'}">
              Net: ${monthNet >= 0 ? '+' : '−'}${fmt(Math.abs(monthNet))}
            </span>
          </div>

          <div class="bar-chart-list">
            <div class="bar-row">
              <div class="row">
                <span class="bar-label"><i class="legend-swatch green-swatch"></i>Uang Masuk & Pelunasan</span>
                <b class="amount">+${fmt(monthIn)}</b>
              </div>
              <div class="bar-track">
                <div class="bar-fill green-fill" style="width:${monthIn > 0 ? Math.max(6, barInPct) : 0}%"></div>
              </div>
            </div>

            <div class="bar-row">
              <div class="row">
                <span class="bar-label"><i class="legend-swatch rose-swatch"></i>Belanja & Pengeluaran Kas</span>
                <b class="amount negative">−${fmt(monthOut)}</b>
              </div>
              <div class="bar-track">
                <div class="bar-fill rose-fill" style="width:${monthOut > 0 ? Math.max(6, barOutPct) : 0}%"></div>
              </div>
            </div>

            <div class="bar-row">
              <div class="row">
                <span class="bar-label"><i class="legend-swatch amber-swatch"></i>Pinjaman Uang Keluar</span>
                <b class="amount warning">−${fmt(monthLoanOut)}</b>
              </div>
              <div class="bar-track">
                <div class="bar-fill amber-fill" style="width:${monthLoanOut > 0 ? Math.max(6, barLoanPct) : 0}%"></div>
              </div>
            </div>

            <div class="split-volume-box">
              <div class="row" style="font-size:11px">
                <span>Proporsi Aktivitas Transaksi: <b>Cash ${cashVolPct}%</b></span>
                <span><b>Digital ${bankVolPct}%</b></span>
              </div>
              <div class="dual-bar">
                <div class="dual-cash" style="width:${cashVolPct}%"></div>
                <div class="dual-bank" style="width:${bankVolPct}%"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ACCORDION MODERN: CATAT UANG MASUK / KELUAR -->
      <details class="action-accordion">
        <summary>
          <div class="acc-trigger-left">
            <span class="acc-badge green">+</span>
            <div class="acc-text">
              <strong>Catat Uang Masuk / Pengeluaran Kas</strong>
              <small>Tambahkan pemasukan kas bersama atau catat belanja kebutuhan rumah</small>
            </div>
          </div>
          <span class="acc-chevron">▾</span>
        </summary>
        <div class="acc-body stack">
          <div class="preset-row">
            <span>Isi cepat keperluan:</span>
            ${presets.map(p => btn(p, 'kasPreset', 'chip-btn', `data-note="${esc(p)}"`)).join('')}
          </div>
          <form id="financeEntry" class="formgrid">
            ${select('Jenis Transaksi', 'type', '<option value="deposit">➕ Uang Masuk (Pemasukan Kas)</option><option value="expense">➖ Uang Keluar (Belanja / Beban Kas)</option>')}
            ${select('Sumber / Akun Kas', 'account', '<option value="cash">Cash (Uang Tunai)</option><option value="bank">Digital (Rekening / Transfer)</option>')}
            ${field('Nominal (MAD)', 'amount', 'number', '', 'required min="0.01" step="0.01" placeholder="Contoh: 150.00"')}
            ${field('Catatan / Keperluan', 'note', 'text', '', 'required maxlength="500" placeholder="Misal: Iuran kas bulan November"')}
            <button class="primary full" type="submit">✓ Simpan Transaksi Kas</button>
          </form>
        </div>
      </details>
    </section>

    <!-- BAGIAN 2: 2 KOLOM (KIRI: RIWAYAT & FILTER, KANAN: PINJAMAN UANG & BARANG) -->
    <div class="columns">
      <!-- KOLOM KIRI: RIWAYAT & ARUS KAS BULANAN -->
      <section class="glass panel stack">
        <div class="heading" style="margin-bottom:0">
          <div>
            <div class="eyebrow">BUKU BESAR & ARUS KAS</div>
            <h2>Riwayat Bulanan</h2>
          </div>
          <label class="month-picker-wrap" aria-label="Pilih bulan laporan">
            <small>Periode</small>
            <input type="month" id="financeMonth" value="${esc(month)}">
          </label>
        </div>

        <!-- RINGKASAN TOTAL MASUK VS KELUAR PER BULAN -->
        <div class="cashflow-summary">
          <div class="row">
            <small style="font-weight:700">Rekapitulasi Bulan ${esc(month)}</small>
            <span class="status ${monthNet >= 0 ? 'ok' : 'rejected'}">
              Selisih: ${monthNet >= 0 ? '+' : '−'}${fmt(Math.abs(monthNet))}
            </span>
          </div>
          <div class="cashflow-grid">
            <div class="cf-box">
              <small>Total Masuk</small>
              <b class="amount">+${fmt(monthIn)}</b>
            </div>
            <div class="cf-box">
              <small>Belanja / Keluar</small>
              <b class="amount negative">−${fmt(monthOut)}</b>
            </div>
            <div class="cf-box">
              <small>Pinjaman Keluar</small>
              <b class="amount warning">−${fmt(monthLoanOut)}</b>
            </div>
          </div>
          <div class="cf-meter" title="Perbandingan Uang Masuk vs Uang Keluar">
            <div class="cf-meter-in" style="width:${inPct}%"></div>
          </div>
        </div>

        <!-- FILTER RIWAYAT INTERAKTIF -->
        <div class="filter-bar" role="tablist" aria-label="Filter riwayat kas">
          ${[
            ['all', 'Semua', counts.all],
            ['in', 'Masuk', counts.in],
            ['out', 'Keluar', counts.out],
            ['loan', 'Pinjaman', counts.loan],
            ['cash', 'Cash', counts.cash],
            ['bank', 'Digital', counts.bank]
          ].map(([key, label, count]) =>
            btn(`${label} <span>${count}</span>`, 'filterKas', `filter-pill ${filter === key ? 'active' : ''}`, `data-filter="${key}"`)
          ).join('')}
        </div>

        <!-- DAFTAR TRANSAKSI -->
        <div class="tx-list">
          ${filteredEntries.length ? filteredEntries.map(e => {
            const isIn = e.type === 'deposit' || e.type === 'repay';
            const isLoan = e.type === 'loan';
            const sign = isIn ? '+' : '−';
            const iconClass = isIn ? 'green' : isLoan ? 'amber' : 'rose';
            const amtClass = isIn ? '' : isLoan ? 'warning' : 'negative';
            const symbol = isIn ? '↓' : isLoan ? '⇄' : '↑';
            return `
              <div class="tx-card">
                <div class="tx-left">
                  <span class="tx-icon ${iconClass}">${symbol}</span>
                  <div class="tx-info">
                    <span class="tx-title">${esc(e.note)}</span>
                    <div class="tx-sub">
                      <span class="tx-tag">${esc(labels[e.type] || e.type)}</span>
                      <span class="tx-tag">${e.account === 'cash' ? '₵ Cash' : '◈ Digital'}</span>
                      <span>${esc(e.date)}</span>
                      <span>· ${esc(name(e.member))}</span>
                    </div>
                  </div>
                </div>
                <div class="tx-right">
                  <b class="amount ${amtClass}">${sign}${fmt(e.amount)}</b>
                  <small>${e.type === 'loan' ? (remaining(db, e.id) > 0 ? `Sisa ${fmt(remaining(db, e.id))}` : 'Lunas') : 'Tercatat'}</small>
                </div>
              </div>
            `;
          }).join('') : `
            <div class="empty">
              <div class="symbol">◈</div>
              <h3>Belum ada transaksi yang cocok</h3>
              <p>${monthEntries.length ? 'Tidak ada catatan untuk filter ini pada bulan terpilih.' : 'Belum ada transaksi kas pada bulan ' + esc(month) + '.'}</p>
            </div>
          `}
        </div>
      </section>

      <!-- KOLOM KANAN: PINJAMAN UANG & INVENTARIS BARANG -->
      <div class="stack">
        <!-- PANEL 1: PINJAMAN UANG KAS -->
        <section class="glass panel stack">
          <div class="heading" style="margin-bottom:0">
            <div>
              <div class="eyebrow">PIUTANG ANGGOTA</div>
              <h2>Pinjaman Uang Kas</h2>
            </div>
            <span class="status ${activeLoans.length ? 'pending' : 'ok'}">
              ${activeLoans.length ? `${activeLoans.length} Belum Lunas` : 'Semua Lunas'}
            </span>
          </div>

          <details class="action-accordion">
            <summary>
              <div class="acc-trigger-left">
                <span class="acc-badge amber">⇄</span>
                <div class="acc-text">
                  <strong>+ Catat Pinjaman Uang</strong>
                  <small>Pinjam sementara dari saldo Cash atau Digital kas</small>
                </div>
              </div>
              <span class="acc-chevron">▾</span>
            </summary>
            <div class="acc-body">
              <form id="financeLoan" class="formgrid">
                ${select('Anggota Peminjam', 'member', options(active))}
                ${select('Ambil dari Sumber', 'account', '<option value="cash">Cash (Tunai)</option><option value="bank">Digital (Bank)</option>')}
                ${field('Nominal Pinjaman (MAD)', 'amount', 'number', '', 'required min="0.01" step="0.01" placeholder="Contoh: 100.00"')}
                ${field('Keperluan / Catatan', 'note', 'text', '', 'maxlength="500" placeholder="Misal: Talangan paket / keperluan mendadak"')}
                <button class="primary full" type="submit">✓ Catat Pinjaman Uang</button>
              </form>
            </div>
          </details>

          <div class="loan-list">
            ${activeLoans.length ? activeLoans.map(e => {
              const left = remaining(db, e.id);
              const paidAmt = e.amount - left;
              const pct = Math.min(100, Math.round((paidAmt / e.amount) * 100));
              return `
                <div class="loan-card active-loan">
                  <div class="row">
                    <div>
                      <strong>${esc(name(e.member))}</strong>
                      <small style="display:block">${esc(e.date)} · ${e.account === 'cash' ? '₵ Cash' : '◈ Digital'}</small>
                    </div>
                    <div style="text-align:right">
                      <b class="amount warning">${fmt(left)}</b>
                      ${paidAmt > 0 ? `<small style="display:block">Dari total ${fmt(e.amount)}</small>` : `<small style="display:block">Belum dicicil</small>`}
                    </div>
                  </div>
                  <p class="note" style="margin:0">${esc(e.note)}</p>
                  ${paidAmt > 0 ? `<div class="progress" style="margin:2px 0"><div style="width:${pct}%"></div></div>` : ''}
                  <form id="financeSettle" data-ref="${esc(e.id)}" class="loan-settle-form">
                    <input name="amount" type="number" min="0.01" max="${(left / 100).toFixed(2)}" step="0.01" value="${(left / 100).toFixed(2)}" aria-label="Nominal pelunasan MAD" required>
                    <button class="primary" type="submit">✓ Bayar / Lunasi</button>
                  </form>
                </div>
              `;
            }).join('') : `
              <p class="hint" style="margin:4px 0">Tidak ada pinjaman uang yang sedang berjalan.</p>
            `}
          </div>

          ${settledLoans.length ? `
            <details class="settled-drawer">
              <summary>Riwayat Pinjaman Lunas (${settledLoans.length})</summary>
              <div class="loan-list" style="margin-top:8px">
                ${settledLoans.slice().reverse().map(e => `
                  <div class="loan-card">
                    <div class="row">
                      <b>${esc(name(e.member))}</b>
                      <span class="status ok">✓ LUNAS · ${fmt(e.amount)}</span>
                    </div>
                    <small>${esc(e.date)} · ${e.account === 'cash' ? 'Cash' : 'Digital'} · ${esc(e.note)}</small>
                  </div>
                `).join('')}
              </div>
            </details>
          ` : ''}
        </section>

        <!-- PANEL 2: PINJAMAN & INVENTARIS BARANG -->
        <section class="glass panel stack">
          <div class="heading" style="margin-bottom:0">
            <div>
              <div class="eyebrow">INVENTARIS BERSAMA</div>
              <h2>Pinjaman Barang</h2>
            </div>
            <span class="status ${borrowedItems.length ? 'info' : 'ok'}">
              ${availableItems.length}/${f.items.length} Tersedia
            </span>
          </div>

          <details class="action-accordion">
            <summary>
              <div class="acc-trigger-left">
                <span class="acc-badge blue">📦</span>
                <div class="acc-text">
                  <strong>+ Catat Pinjaman Barang</strong>
                  <small>Catat peminjaman alat atau barang inventaris rumah</small>
                </div>
              </div>
              <span class="acc-chevron">▾</span>
            </summary>
            <div class="acc-body">
              <form id="financeItem" class="formgrid">
                ${field('Nama Barang Inventaris', 'name', 'text', '', 'required maxlength="120" placeholder="Misal: Setrika Uap / Kabel Roll"')}
                ${select('Dipinjam Oleh', 'borrower', options(active))}
                <button class="primary full" type="submit">✓ Catat Peminjaman Barang</button>
              </form>
            </div>
          </details>

          <div class="item-grid">
            ${f.items.length ? f.items.slice().reverse().map(i => `
              <div class="item-card ${i.borrower ? 'borrowed' : ''}">
                <div>
                  <strong>${esc(i.name)}</strong>
                  <small style="display:block;margin-top:2px">
                    ${i.borrower
                      ? `Dipinjam oleh <b>${esc(name(i.borrower))}</b>${i.deadline ? ' · sejak ' + esc(i.deadline) : ''}`
                      : 'Tersedia di rumah · Siap dipakai'}
                  </small>
                </div>
                ${i.borrower
                  ? `<form id="financeReturn" data-ref="${esc(i.id)}"><button class="primary" type="submit" style="min-height:34px;padding:6px 12px;font-size:12px">✓ Kembalikan</button></form>`
                  : `<span class="status ok">TERSEDIA</span>`}
              </div>
            `).join('') : `
              <p class="hint" style="margin:4px 0">Belum ada barang inventaris yang dicatat.</p>
            `}
          </div>
        </section>
      </div>
    </div>
  </div>`;
}

export function submitFinance(db, form, v, active) {
  const f = init(db);
  const date = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Africa/Casablanca',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date());
  const base = {member: active, date, deadline: '', category: 'Umum', ref: ''};

  if (form.id === 'financeEntry' || form.id === 'financeLoan') {
    record(db, {
      ...base,
      ...v,
      type: form.id === 'financeLoan' ? 'loan' : v.type,
      note: v.note?.trim() || 'Pinjaman uang',
      amount: money(v.amount)
    }, active);
    return true;
  }

  if (form.id === 'financeSettle') {
    const e = f.entries.find(x => x.id === form.dataset.ref);
    const left = e ? remaining(db, e.id) : 0;
    if (!e || !left) throw Error('Pinjaman sudah dilunasi.');
    const payAmount = v.amount ? money(v.amount) : left;
    if (payAmount > left) throw Error('Nominal pelunasan melebihi sisa pinjaman.');
    record(db, {
      ...base,
      type: 'repay',
      account: e.account,
      member: e.member,
      amount: payAmount,
      ref: e.id,
      note: (payAmount < left ? 'Cicilan: ' : 'Pelunasan: ') + e.note
    }, active);
    return true;
  }

  if (form.id === 'financeItem') {
    if (!v.name.trim()) throw Error('Isi nama barang.');
    f.items.push({
      id: uid(),
      name: v.name.trim(),
      condition: 'Dicatat',
      borrower: v.borrower,
      deadline: date,
      history: [{
        at: new Date().toISOString(),
        action: 'Dipinjam',
        member: v.borrower,
        condition: 'Dicatat',
        actor: active
      }]
    });
    return true;
  }

  if (form.id === 'financeReturn') {
    const i = f.items.find(x => x.id === form.dataset.ref);
    if (!i?.borrower) throw Error('Barang sudah dikembalikan.');
    i.history.push({
      at: new Date().toISOString(),
      action: 'Dikembalikan',
      member: i.borrower,
      condition: i.condition,
      actor: active
    });
    i.borrower = null;
    i.deadline = null;
    return true;
  }

  return false;
}
